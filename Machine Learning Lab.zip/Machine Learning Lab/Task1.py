from sklearn . model_selection import train_test_split
from sklearn . tree import DecisionTreeClassifier
from sklearn . datasets import load_breast_cancer
print("Import succeeded")

cancer = load_breast_cancer () # Load in the data
# Create the training and test sets
X_train , X_test , y_train , y_test = train_test_split ( cancer . data , cancer . target , stratify = cancer .
target , random_state =42 )
print("Splitting suceeded")

tree = DecisionTreeClassifier ( random_state =0)
tree . fit ( X_train , y_train )
print("Fitting Succeeded")

print (" Training set accuracy : {:.3f}". format ( tree . score ( X_train , y_train )))
print (" Test set accuracy : {:.3f}". format ( tree . score ( X_test , y_test )))
