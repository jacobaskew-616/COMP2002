import matplotlib . pyplot as plt
from sklearn . decomposition import PCA
from sklearn . datasets import load_iris
from sklearn . neighbors import KNeighborsClassifier
import pandas
import numpy as np
print("Import succeeded")

# Load the Iris data .
# Load the data using Panda . Print it to view it .
data = pandas.read_csv ("iris.csv")
print ( data )

# Extract the inputs .
inputs = data . values [:,:-1]. astype ( float )
# Extract the targets - convert to numerical values to help with
# colouring when we plot the results .
cls = ["Iris-setosa", "Iris-versicolor", "Iris-virginica"]
targets = [ cls . index (c) for c in data . values [:,-1]. astype ( str )]
targets = np.array ( targets )


# Project the data into two dimensions using PCA .
pca = PCA ( n_components =2)
compressed = pca . fit_transform ( inputs )

# Train the classifier .
classifier = KNeighborsClassifier ( n_neighbors =10 )
classifier . fit ( inputs , targets )
classifiedData = classifier . predict ( inputs )

# Plot the results .
plt . figure ()
plt . scatter ( compressed [:,0], compressed [:,1], c= classifiedData )
plt . title ("PCA projection - classified ")
plt . savefig ("iris_pca_classified.png", bbox_inches ="tight")
plt . show ()
