import matplotlib . pyplot as plt
from sklearn . datasets import load_digits
from sklearn.decomposition import PCA
from sklearn.neighbors import KNeighborsClassifier

# Load the data
digits = load_digits()
# Extract the three parts of the data .
data = digits.data
images = digits.images
target = digits.target


plt.figure()
plt.imshow(images[0], cmap="gray")
plt.title(f"Digit: {target[0]}")
plt.show()

pca = PCA(n_components=2)
compressed = pca.fit_transform(data)

# Train classifier
classifier = KNeighborsClassifier(n_neighbors=5)
classifier.fit(compressed, target)

# Predict
predicted = classifier.predict(compressed)

# Plot PCA result
plt.figure()
plt.scatter(compressed[:,0], compressed[:,1], c=predicted)
plt.title("Digits PCA projection - classified")
plt.show()