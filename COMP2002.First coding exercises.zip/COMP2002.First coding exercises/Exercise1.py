""" 
This first exercise is designed to familiarise you with the syntax and logic of Python.
 Create a simple 1-D array in Python of length 7.
 Check the length of your array.
 Select just the fourth element of your array.
 Add an element to your array and check the length to ensure it has been added successfully.
 Remove the second element of your array.
"""

print(" ")
print("Exercise 1:")
print(" ")
array = [1,2,3,4,5,6,7] # Defining array

print(array, "are the elements in the array") # Showing the elements of the array
print(" ")

print(len(array),"is the amount of elements in the array") # Finding the length of the array            
print(" ")

fourthElement = array[3] 
print(fourthElement,"is the fourth element in the array") # Printing the fourth element in the array
print(" ")

array.append(8) # Adding another number to the end of the array
print("I have added the number 8 to the end of the array")
print(array, "is now the elements in the array")
print(len(array),"is now the amount of elements in the array") # Proving that a value has actually been added
print(" ")

secondElement = array[1] # Creating a variable that holds the second element in the array
print("I am going to remove the second element in the array")
array.remove(secondElement) # Removing the second element
print(array, "is now the elements in the array") # Showing that is has been removed from the array
print(len(array), "is now the amount of elements in the array") # Showing the new length of the array
print(" ")