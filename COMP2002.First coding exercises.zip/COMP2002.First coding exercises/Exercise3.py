import numpy as np
import matplotlib.pyplot as plt

# Generate data
uniform_data = np.random.rand(100)     # Uniform distribution
normal_data = np.random.randn(100)     # Normal distribution


# Box Plot
plt.figure()
plt.boxplot([uniform_data, normal_data], labels=["Uniform", "Normal"])
plt.title("Boxplot of Uniform vs Normal Distribution")
plt.show()


# Histogram
plt.figure()
plt.hist(uniform_data, bins=20, alpha=0.7, label="Uniform")
plt.hist(normal_data, bins=20, alpha=0.7, label="Normal")
plt.title("Histogram of Uniform vs Normal Distribution")
plt.legend()
plt.show()
