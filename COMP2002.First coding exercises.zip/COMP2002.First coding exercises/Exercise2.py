import matplotlib.pyplot as plt
import numpy as np

"""
Generate a plot of the function y = sin(x) between the values −π and π.
 Use the Numpy function np.linspace to generate 100 values in that region (the Numpy function np.linspace
will also be useful).
1
 The Numpy function np.sin will compute the y value.
 The Matplotlib function plt.plot(x, y) can be used to plot the graph. You can also use plt.scatter(x, y)
to get points rather than a line.
 See if you can find out how to change the colour of the line (for plt.plot) and dots (for plt.scatter).
"""
print(" ")
Pi = np.pi
negativePi = -np.pi

print("Pi:", Pi)
print("Negative Pi:", negativePi)
print(" ")


x = np.linspace(negativePi,Pi,100) # Defining 100 numbers inbetween negative Pi and Pi
print(" ") 

y = np.sin(x) # Applies sin to every element in the array

plt.plot(x, y, color="red")
plt.show()
