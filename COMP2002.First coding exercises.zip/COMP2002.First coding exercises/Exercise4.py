# Fibonacci

n = 10
a = 0
b = 1
next = b  
count = 1

while count <= n:
    print(next, end=" ")
    count += 1
    a, b = b, next
    next = a + b
print()

"""
iteration 1:

a = 0 
b = 1
next = 1

a turns into 1, b remains as 1, next becomes a + b = 2

iteration 2:
a = 1
b = 1
next = 2

a remains as 1, b turns into 2, next becomes a + b = 3

Iteration 3:
a becomes 2, b becomes 3, next becomes 5 

Iteration4:
a becomes 3, b becomes 5, next becomes 8
"""